package com.mockitotutorial.happyhotel.booking;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

import java.time.LocalDate;

import org.junit.jupiter.api.*;

class Test01FirstMock {

	private BookingService bookingService;
	private PaymentService paymentServiceMock;
	private RoomService roomServiceMock;
	private BookingDAO bookingDAOMock;
	private MailSender mailSenderMock;

	@BeforeEach
	void setUp() {
		paymentServiceMock = mock(PaymentService.class);
		roomServiceMock = mock(RoomService.class);
		bookingDAOMock = mock(BookingDAO.class);
		mailSenderMock = mock(MailSender.class);

		bookingService = new BookingService(paymentServiceMock, roomServiceMock, bookingDAOMock, mailSenderMock);
	}

	@Test
	void calculatePrice_test() {
		//given
		BookingRequest bookingRequest=new BookingRequest("1", LocalDate.of(2024,01, 01),LocalDate.of(2024, 01, 5) , 2, false);
		double exp=4*50.0*2;
		//when
		double actual=bookingService.calculatePrice(bookingRequest);
		assertEquals(exp,actual);
	}

}

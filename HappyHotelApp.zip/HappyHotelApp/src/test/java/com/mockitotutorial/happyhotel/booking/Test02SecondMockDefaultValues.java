package com.mockitotutorial.happyhotel.booking;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

import java.time.LocalDate;

import org.junit.jupiter.api.*;

class Test02SecondMockDefaultValues {

	private BookingService bookingService;
	private PaymentService paymentServiceMock;
	private RoomService roomServiceMock;
	private BookingDAO bookingDAOMock;
	private MailSender mailSenderMock;

	@BeforeEach
	void setUp() {
		paymentServiceMock = mock(PaymentService.class);
		roomServiceMock = mock(RoomService.class);
		bookingDAOMock = mock(BookingDAO.class);
		mailSenderMock = mock(MailSender.class);

		bookingService = new BookingService(paymentServiceMock, roomServiceMock, bookingDAOMock, mailSenderMock);
	}

	@Test
	@DisplayName("Testing Available rooms")
	void testing_get_available_rooms() {
		//given
		int exp=0;
		
		//when
		int actual=bookingService.getAvailablePlaceCount();
		//then
		System.out.println("Available Room Count "+roomServiceMock.getRoomCount());
		System.out.println("Get Available Rooms "+roomServiceMock.getAvailableRooms());
		assertEquals(exp, actual);
	}

}

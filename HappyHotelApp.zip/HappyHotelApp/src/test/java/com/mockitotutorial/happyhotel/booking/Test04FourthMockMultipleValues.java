package com.mockitotutorial.happyhotel.booking;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.*;

import org.junit.jupiter.api.*;

class Test04FourthMockMultipleValues {

	private BookingService bookingService;
	private PaymentService paymentServiceMock;
	private RoomService roomServiceMock;
	private BookingDAO bookingDAOMock;
	private MailSender mailSenderMock;

	@BeforeEach
	void setUp() {
		paymentServiceMock = mock(PaymentService.class);
		roomServiceMock = mock(RoomService.class);
		bookingDAOMock = mock(BookingDAO.class);
		mailSenderMock = mock(MailSender.class);

		bookingService = new BookingService(paymentServiceMock, roomServiceMock, bookingDAOMock, mailSenderMock);
	}

	@Test
	void testing_custom_values() {
		// given
		int expFirst = 2;
		int expSecond = 7;
		List<Room> rooms = Arrays.asList(new Room("1", 5), new Room("2", 2));

		when(this.roomServiceMock.getAvailableRooms()).thenReturn(Collections.singletonList(new Room("1", 2)))
				.thenReturn(rooms);
		// when
		int firstActual = bookingService.getAvailablePlaceCount();
		int secondActual = bookingService.getAvailablePlaceCount();
		// then
		assertAll(() -> assertEquals(expFirst, firstActual), () -> assertEquals(expSecond, secondActual));

	}

}

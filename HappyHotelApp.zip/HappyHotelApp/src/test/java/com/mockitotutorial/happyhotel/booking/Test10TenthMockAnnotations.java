package com.mockitotutorial.happyhotel.booking;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.function.Executable;
import org.mockito.ArgumentCaptor;

class Test10TenthMockAnnotations {

	private BookingService bookingService;
	private PaymentService paymentServiceMock;
	private RoomService roomServiceMock;
	private BookingDAO bookingDAOMock;
	private MailSender mailSenderMock;
	
	private ArgumentCaptor<Double> doubleCaptor;

	@BeforeEach
	void setUp() {
		paymentServiceMock = mock(PaymentService.class);
		roomServiceMock = mock(RoomService.class);
		bookingDAOMock = mock(BookingDAO.class);
		mailSenderMock = mock(MailSender.class);
		
		doubleCaptor=ArgumentCaptor.forClass(Double.class);

		bookingService = new BookingService(paymentServiceMock, roomServiceMock, bookingDAOMock, mailSenderMock);
	}
	
	//Argument Captor
	@Test
	void testing_argument_captor () {
		//given
		BookingRequest bookingRequest=new BookingRequest("1", LocalDate.of(2024,01, 01),LocalDate.of(2024, 01, 9) , 4, true);
		BookingRequest bookingRequest2=new BookingRequest("1", LocalDate.of(2024,01, 01),LocalDate.of(2024, 01, 9) , 4, true);

		bookingService.makeBooking(bookingRequest2);
		verify(paymentServiceMock,times(1)).pay(eq(bookingRequest2), doubleCaptor.capture());
		
		Double values=doubleCaptor.getValue();
		System.out.println("Value-->"+values);
		
		assertEquals(1600, values);
				
		
		
	}

}

package com.mockitotutorial.happyhotel.booking;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.*;

import org.junit.jupiter.api.*;
import org.mockito.*;

class Test12MockingStaticMethods {

	private BookingService bookingService;
	private PaymentService paymentServiceMock;
	private RoomService roomServiceMock;
	private BookingDAO bookingDAOMock;
	private MailSender mailSenderMock;
	
	private ArgumentCaptor<Double> doubleCaptor;

	@BeforeEach
	void setUp() {
		paymentServiceMock = mock(PaymentService.class);
		roomServiceMock = mock(RoomService.class);
		bookingDAOMock = mock(BookingDAO.class);
		mailSenderMock = mock(MailSender.class);
		
		doubleCaptor=ArgumentCaptor.forClass(Double.class);

		bookingService = new BookingService(paymentServiceMock, roomServiceMock, bookingDAOMock, mailSenderMock);
	}
	

	@Test
	void testing_static_mocks() {
		//given
		try(MockedStatic<CurrencyConverter> mockedConverter=mockStatic(CurrencyConverter.class)){
			BookingRequest bookingRequest=new BookingRequest("1", LocalDate.of(2024,01, 01),LocalDate.of(2024, 01, 5) , 2, false);
			mockedConverter.when(()->CurrencyConverter.toEuro(anyDouble())).
			thenReturn(400.0);
			
			double expected=400;
			
			//when
			double actual=bookingService.calculatePrice(bookingRequest);

			assertEquals(expected,actual);
	
			
		}
	}

	

}

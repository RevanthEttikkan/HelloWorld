package com.microservices.limits_services.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.microservices.limits_services.Class.Limits;
import com.microservices.limits_services.Configuration.LimitsConfiguration;

@RestController
public class Controller {
	
	@Autowired
	private LimitsConfiguration limitsConfig;

	@GetMapping("get-limits")
	public Limits getLimits() {
		return new Limits(limitsConfig.getMinimum(),limitsConfig.getMaximum());
	}
}
